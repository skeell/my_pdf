a_s = input('Coefficiente a = ')

if a_s.isnumeric():
    a = float(a_s)
else:
    print('formato errato')
