print('inizio')

N = 0

c = 1
while c <= N:
    print(c)
    c = c + 1

c = 0
while c < N:
    print(c + 1)
    c = c + 1

print("fine")
