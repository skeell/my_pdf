##
#  Display your name in a box.
#

print("+-----+")
print("| Ben |")
print("+-----+")
