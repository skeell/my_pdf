##
#  Display 4 common phrases in English and another language.
#

print("English                         French")
print("-----------------------------   ------------------------------------")
print("Good morning.                   Bonjour.")
print("It is a pleasure to meet you.   C'est un plaisir de vous rencontrer.")
print("Please call me tomorrow.        S'il vous plait appelez-moi demain.")
print("Have a nice day!                Bonne journee!")
