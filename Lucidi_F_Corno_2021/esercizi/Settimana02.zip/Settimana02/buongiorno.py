from math import sqrt

print("Buongiorno")
print("a tutti")

print("Buongiorno", "a tutti")

print(3, 2)
print(3+2)

a = sqrt(7)

print("ABC", "XYZ")
print("ABC"+"XYZ")
# print("ABC" + 3)
print("ABC" + str(3+2))
