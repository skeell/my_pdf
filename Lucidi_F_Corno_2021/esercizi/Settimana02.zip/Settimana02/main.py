print("Buongiorno")
