# Esercizi di lettura dati
print('Ciao')

nome = input("Come ti chiami?")

print(f"Il tuo nome: {nome.upper()}" )

s = input("Quanti anni hai? ")
anni = int(s)

print(f"Sei nato nell'anno {2021-anni}")
